//��N*N�ķ������̷�����N���ʺ� 
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int result=0;
int a[15];
int n;
void search(int cur){
	if(cur==n){
		result++;	
	}
	else
		for(int i=0;i<n;i++){
			int flag=1;
			a[cur]=i;
			for(int j=0;j<cur;j++)
				if((a[cur]==a[j])||(cur-a[cur]==j-a[j])||(cur+a[cur]==j+a[j])){
					flag=0;
					break;
				}
			
			if(flag) search(cur+1);
			
	}
}
int main(){
	while(1){
		memset(a,0,sizeof(a));
		result=0;
		scanf("%d",&n);
		if(n!=0){
			search(0);
			printf("%d\n",result);
		}
		else break;
	}
	
}

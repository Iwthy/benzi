#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int op[100005];
int flag[10010];
int main() {
	int T;
	scanf("%d", &T);
	while (T--) {
		memset(op, 0, sizeof(op));
		memset(flag, 0, sizeof(flag));
		int n;
		scanf("%d", &n);
		int left = 0;
		int right = 0;
		for (int i = 1; i <= n;i++) {
			scanf("%d", &left);
			scanf("%d", &right);
			for (int yo = left; yo <= right;yo++) {
				op[yo] = i;
			}
		}
		for (int i = 1; i <=100000;i++) {
			if (op[i]!=0) {
				flag[op[i]] = 1;
			}
		}
		int sum = 0;
		for (int i = 1; i <= n;i++) {
			if (flag[i]!=0) {
				sum++;
			}
		}
		printf("%d\n", sum);
	}
	return 0;
}

/**
* ����������� 
* �������� 
* 
*/

#include <cstdio>
#include <cstdlib>
#include <time.h>
#define FILEPATH "test.txt"   //���·�� 
using namespace std; 
void getFileInfo(int a[]);
int a[120];

int main()
{
	
//	getFileInfo(a);
//	int i=0;
//	while(a[i]!=0)
//	{
//		printf("%d\n",a[i]);
//		i++;
//	}
	
	
	FILE * fp;
	if((fp=fopen(FILEPATH,"w"))==NULL)
	{
		printf("fail to open...\n");
		exit(0);
	}
	
	int min,max,num;
	printf("���룺��Сֵ ���ֵ ����\n"); 
	scanf("%d%d%d",&min,&max,&num);
	srand((unsigned)time(NULL));
	
	for(int i=0;i<num;i++)
	{
		
		fprintf(fp,"%d\n",rand()%(max-min)+min);
		//fprintf(fp,"%d\n",i);
	}	
	fclose(fp);
	

	return 0;	
} 


/*
//��ȡ����
void getFileInfo(int a[])
{
	FILE * fp;
	if((fp=fopen("test.txt","r"))==NULL)
	{
		printf("fail to open...\n");
		exit(0);
	}
	
	int i=0;
	while((fscanf(fp,"%d",&a[i++]))!=EOF);
	
	fclose(fp);
}
*/





#include<stdio.h>
#include<string.h>
#include<stdlib.h>
struct node {
	long long int number;
	long long int wide;
	long long int high;
	struct node* front;
	struct node* next;
};
typedef struct node NODE;
long long int sum[100005];
int main() {
	memset(sum, 0, sizeof(sum));
	NODE *left_edge, * right_edge, *pre, *now, *temp;

	long long int n;
	long long int a, b;
	scanf("%lld", &n);
	left_edge = (NODE *)malloc(sizeof(NODE));
	left_edge->next = NULL;
	left_edge->front = NULL;
	left_edge->wide = 0;
	left_edge->high = 10000000;
	now = left_edge;
	pre = left_edge;
	for (long long int i = 0; i < n;i++) {//����ǳ�ĵط�
		scanf("%lld %lld", &a, &b);
		temp = (NODE *)malloc(sizeof(NODE));
		temp->wide = a;
		temp->high = b;
		temp->number = i;
		temp->front = pre;
		temp->next = NULL;
		pre->next = temp;
		pre = temp;
		if (now->high>b) {
			now = temp;
		}
	}
	right_edge = (NODE *)malloc(sizeof(NODE));
	right_edge->wide = 0;
	right_edge->high = 10000000;
	right_edge->front = temp;
	temp->next = right_edge;
	right_edge->next = NULL;

	//����ʱ��
	long long int time;
	time = 0;
	while (now->next->high != now->front->high) {
		sum[now->number] = time + now->wide;
		if (now->front->high < now->next->high) {
			time = time + (now->front->high - now->high) * now->wide;
			now->front->wide = now->front->wide + now->wide;
			now->front->next = now->next;
			now->next->front = now->front;
			now = now->front;
		}
		else if (now->front->high > now->next->high) {
			time = time + (now->next->high - now->high) * now->wide;
			now->next->wide = now->next->wide + now->wide;
			now->front->next = now->next;
			now->next->front = now->front;
			now = now->next;
		}
		if (now->high < now->front->high && now->high < now->next->high)
			continue;
		if (now->front->high < now->next->high) {//ˮ���ʹ��� �ҵ���һ����ʹ�
			while (now->front->high < now->high) {
				now = now->front;
			}
		}
		else if (now->front->high>now->next->high) {
			while (now->next->high < now->high) {
				now = now->next;
			}
		}
	}
	sum[now->number] = time + now->wide;//���������� ֻʣ�����Ե �м���ߴ� �ұ�Ե
	//���м�Ҳ��������
	for (long long int i = 0; i < n;i++) {
		printf("%lld\n",sum[i]);
	}
}



#include<stdio.h>
#include<string.h>
#include<stdlib.h>
char s[1000];
int point1 = 0;
int point2 ;
void gethead() {
	printf("destroy tail\n");
	printf("free list node\n");
	printf("generic list: ");
	int depth = -1;
	for (int i = point1; s[i] != '\0';i++) {
		if (s[i]=='(') {
			depth++;
			if (depth == 0) {
				point1 = i + 1;
			}
			continue;
		}
		else if (s[i]==')') {
			depth--;
			if (depth==0) {
				point2 = i;
				break;
			}
			continue;
		}
		else if (s[i]==','&&depth==0) {
			point2 = i - 1;
			break;
		}

	}
	for (int i = point1; i <= point2;i++) {
		printf("%c", s[i]);
	}
	printf("\n");
}
void gettail() {
	printf("free head node\nfree list node\ngeneric list: ");
	int depth = -1;
	int flag = 0;
	for (int i = point1; s[i] != '\0';i++) {
		if (i==point2) {
			flag = 1;
			break;
		}
		else if (s[i]=='(') {
			depth++;
		}
		else if (s[i]==')') {
			depth--;
		}
		else if (s[i]==','&&depth==0) {
			s[i] = '(';
			point1 = i;
			break;
		}
	}
	if (flag==1) {
		printf("()\n");
		return;
	}
	for (int i = point1; i <= point2;i++) {
		printf("%c", s[i]);
	}
	printf("\n");
}
int main() {

	scanf("%s", s);
	int op;
	int len = strlen(s);
	point2 = len - 1;
	printf("generic list: %s\n", s);
	while (~scanf("%d", &op)) {
		if (op==1) {
			gethead();
		}
		else if (op == 2) {
			gettail();
		}
	}
	return 0;

}

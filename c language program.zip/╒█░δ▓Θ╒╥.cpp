#include<stdio.h>
#include<stdlib.h>
#include<string.h>
struct node {
	int data;
	int number;
};
typedef struct node NODE;
NODE op[100];
void SWAP(NODE* op, int a, int b) {
	int temp1;
	temp1 = op[a].data;
	op[a].data = op[b].data;
	op[b].data = temp1;
	int temp2;
	temp2 = op[a].number;
	op[a].number = op[b].number;
	op[b].number = temp2;
}
void paixu(NODE *op,int n) {//����ͨ��ð������ 
	for (int i = 1; i <= n;i++) {
		for (int j = i; j <= n;j++) {
			if (op[i].data > op[j].data) {
				SWAP(op, i, j);
			}
		}
	}
	return;
}
int search(NODE* op, int n) {//��Ŀ��Ԫ��
//�����������������Ķ��ַ� �������� 
	int head = 1;
	int tail = n;
	int mid = (head + tail) / 2;
	while (head <= tail) {
		if (op[0].data == op[mid].data) {
			printf("(%d %d)\n", op[mid].data, op[mid].number);
			return 0;
		}
		else if (op[0].data < op[mid].data) {
			tail = mid - 1;
			mid = (tail + head) / 2;
		}
		else if (op[0].data > op[mid].data) {
			head = mid + 1;
			mid = (tail + head) / 2;
		}
	}
	return 1;
}
int main() {
	int n;
	scanf("%d", &n);
	for (int i = 1; i <= n;i++) {
		scanf("%d %d", &op[i].data, &op[i].number);
	}
	scanf("%d", &op[0].data);
	op[0].number = -1;
	paixu(op, n);
	for (int i = 1; i < n; i++) {
		printf("(%d %d)", op[i].data, op[i].number);
	}
	printf("(%d %d)\n", op[n].data, op[n].number);
	int flag = search(op, n);
	if (flag) {
		printf("error\n");
	}
	return 0;
}

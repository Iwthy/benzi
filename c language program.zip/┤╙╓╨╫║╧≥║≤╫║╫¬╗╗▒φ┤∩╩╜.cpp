#include<cstdio>  
#include<iostream>  
#include<cstdlib>  
#include<cstring>  
#include<stack>  
//������Ѫ��   
//A+B^C^D*E^F#  
using namespace std;
int level_outside(char op);
int level_zhan(char op);
int main() {
	int t;
	scanf("%d", &t);
	while (t--) {
		stack<char> k;
		char s[1000];
		scanf("%s", s);
		int len = strlen(s);
		for (int i = 0; i < len; i++) {
			if ((s[i] >= 'a' && s[i] <= 'z') || (s[i] >= 'A' && s[i] <= 'Z')) {
				printf("%c", s[i]);
				continue;
			}
			else {//�Ƿ���   
				if (k.empty()) {
					k.push(s[i]);
				}
				else if (s[i] == '(') {
					k.push(s[i]);
				}
				else if (s[i] == ')') {
					while (k.top() != '(') {
						printf("%c", k.top());
						k.pop();
					}
					k.pop();
				}
				else {
					while (level_outside(s[i]) < level_zhan(k.top())) {//ջ��Ԫ�����ȼ����ڵ�ǰԪ�����ȼ�  
					//��ջ��Ԫ�صõ���������Ԫ����  
						printf("%c", k.top());
						k.pop();
						if (k.empty()) {
							break;
						}
					}
					k.push(s[i]);
				}
			}
		}
		while (!k.empty() && k.top() != '#') {
			printf("%c", k.top());
			k.pop();
		}
		printf("\n");
	}
}
int level_outside(char op) {
	int a;
	if (op == '+' || op == '-') {
		a = 2;
	}
	else if (op == '*' || op == '/') {
		a = 4;
	}
	else if (op == '^') {
		a = 7;
	}
	return a;
}
//��Щ�ַ������ȼ�һ��Ҫע���� �����^��ǰ���^���ȼ��� 
int level_zhan(char op) {
	int a;
	if (op == '+' || op == '-') {
		a = 3;
	}
	else if (op == '*' || op == '/') {
		a = 5;
	}
	else if (op == '^') {
		a = 6;
	}
	else if (op == '(')
		a = 1;
	return a;
}

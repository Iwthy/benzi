#include <stdio.h>  
#include <stdlib.h>  
  
typedef struct node  
{   int    coef, exp;  
    struct node  *next;  
} NODE;  
  
void multiplication( NODE *, NODE * , NODE * );  
void input( NODE * );  
void output( NODE * );  
  
void input( NODE * head )  
{   int flag, sign, sum, x;  
    char c;  
  
    NODE * p = head;  
  
    while ( (c=getchar()) !='\n' )  
    {  
        if ( c == '<' )  
        {    sum = 0;  
             sign = 1;  
             flag = 1;  
        }  
        else if ( c =='-' )  
             sign = -1;  
        else if( c >='0'&& c <='9' )  
        {    sum = sum*10 + c - '0';  
        }  
        else if ( c == ',' )  
        {    if ( flag == 1 )  
             {    x = sign * sum;  
                  sum = 0;  
                  flag = 2;  
          sign = 1;  
             }  
        }  
        else if ( c == '>' )  
        {    p->next = ( NODE * ) malloc( sizeof(NODE) );  
             p->next->coef = x;  
             p->next->exp  = sign * sum;  
             p = p->next;  
             p->next = NULL;  
             flag = 0;  
        }  
    }  
}  
  
void output( NODE * head )  
{  
    while ( head->next != NULL )  
    {   head = head->next;  
        printf("<%d,%d>,", head->coef, head->exp );  
    }  
    printf("\n");  
}  
  
int main()  
{   NODE * head1, * head2, * head3;  
  
    head1 = ( NODE * ) malloc( sizeof(NODE) );  
    input( head1 );  
  
    head2 = ( NODE * ) malloc( sizeof(NODE) );  
    input( head2 );  
  
    head3 = ( NODE * ) malloc( sizeof(NODE) );  
    head3->next = NULL;  
    multiplication( head1, head2, head3 );  
  
    output( head3 );  
    return 0;  
}



void multiplication(NODE *head1,NODE *head2,NODE *head3){    
    NODE *one=head1->next,*two=head2->next;    
    NODE *q1,*q2,*q3;    
    one=head1->next;    
    q1=head3;    
    q2=head3;    
    q3=head3;    
    while(one!=NULL){   
        while(two!=NULL){    
            int tempcoef=one->coef*two->coef;    
            if(tempcoef==0){    
                two=two->next;    
                continue;//ϵ��Ϊ0������һ����     
            }    
            int tempexp=one->exp+two->exp;    
            if(q1->next==NULL){//��������л�û�ж���ʽ     
                NODE *begin;    
                begin=(NODE *)malloc(sizeof(NODE));    
                begin->coef=tempcoef;    
                begin->exp=tempexp;    
                q1->next=begin;    
                begin->next=NULL;    
                //begin��Ϊ�µĽڵ���뵽���������     
            }     
            else{//����������ж���ʽ��ϵ����Ϊ0     
                if(q3->next!=NULL&&q3->next->exp<tempexp){    
                    q2=q3;    
                    while(q2->next!=NULL&&q2->next->exp<tempexp){    
                        q2=q2->next;    
                        q3=q2;    
                    }    
                }    
                else{    
                    while(q2->next!=NULL&&q2->next->exp<tempexp){//������һ���ڵ��ָ��     
                        q2=q2->next;    
                        q3=q2;    
                    }    
                }    
                NODE *p;    
                p=q2->next;//ָ����һ���ڵ�     
                if(q2->next==NULL){//˵��ָ��exp����q2������ָ���ڵ�    
                    NODE *begin=(NODE *)malloc(sizeof(NODE));    
                    begin->coef=tempcoef;    
                    begin->exp=tempexp;    
                    q2->next=begin;    
                    begin->next=NULL;     
                        
                }    
                else if(p->exp==tempexp){//ָ�����    
                    p->coef+=tempcoef;   
                    if(p->coef==0){//ϵ�����Ϊ0��ɾ����ǰ�ڵ�     
                        q2->next=p->next;    
                    }    
                }    
                else if(p->exp>tempexp){//����֮������м��ָ��     
                    NODE *begin=(NODE *)malloc(sizeof(NODE));    
                    begin->coef=tempcoef;    
                    begin->exp=tempexp;    
                    q2->next=begin;    
                    begin->next=p;    
                }    
            }    
            two=two->next;    
            q2=head3;    
        }    
        one=one->next;   
        two=head2->next; //two��С��ʼ��   
    }    
    if(head3->next==NULL){  //����β�� ���һ��Ҫ������   
        NODE *end=(NODE *)malloc(sizeof(NODE));    
        end->coef=0;    
        end->exp=0;    
        end->next=NULL;    
        head3->next=end;    
    }    
    return;    
}

#include<stdio.h>
#include<string.h>
#include<stdbool.h>
#include<malloc.h>
typedef struct student student;
struct student {
	int sid;//student id
	char sname[30];
	struct student* next;
};
//����
student* linklist;
int len;
void init_linklist()
{
	linklist = NULL;
	len = 0;
}
bool addstudent(int studentid, char* name)
{
	student* p;
	p = (student*)malloc(sizeof(student));
	strcpy(p->sname, name);
	p->sid = studentid;
	len++;
	p->next = linklist;
	linklist = p;
	return 1;
}
bool removestudent(char* name)
{
	student* p = linklist;
	student* tmp = p;
	while (p != NULL && strcmp(p->sname, name) != 0)
	{
		tmp = p;
		p = p->next;
	}
	if (p == NULL)//no find
		return 0;
	if (tmp == p)//˵���Ǳ�ͷ
	{
		linklist = p->next;
		free(p);
		len--;
		return 1;
	}
	//�Ǳ�ͷ
	tmp->next = p->next;
	free(p);
	len--;
	return 1;
}
student* findstudent(char* name)
{
	student* p = linklist;
	while (p != NULL && strcmp(p->sname, name) != 0)
		p = p->next;
	if (p == NULL)
		return 0;
	else
		return p;
}
void printlist()
{
	student* p = linklist;
	while (p != NULL)
	{
		printf("name:%s studentID:%d\n", p->sname, p->sid);
		p = p->next;
	}
}
int main(void)
{
	init_linklist();
	addstudent(111, "limin");
	addstudent(222, "xiaoc");
	printlist();
	removestudent("xiaoc");
	printlist();
	char na[30];
	int si;
	printf("input the student you want to add:\n");
	scanf("%s %d", na, &si);
	addstudent(si, na);
	printlist();
	return 0;
}
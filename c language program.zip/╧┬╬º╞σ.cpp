#include<stdio.h> 
#include<string.h> 
#include<stdlib.h> 
int visit[11][11];
char player1;
char player2;
char board[11][11];
int flag = 0;
void dfs(int a, int b, char ch) {
	visit[a][b] = 1;
	if (a < 1 || a > 9 || b < 1 || b > 9) {
		return;
	}
	if (board[a][b] == ch) {
		if (!visit[a - 1][b]) dfs(a - 1, b, ch);
		if (!visit[a + 1][b]) dfs(a + 1, b, ch);
		if (!visit[a][b - 1]) dfs(a, b - 1, ch);
		if (!visit[a][b + 1]) dfs(a, b + 1, ch);
	}
	else if (board[a][b] == '.') {
		flag = 1;
		return;
	}
	return;
}
void if_ko(int a, int b) {
	int ans = 0;
	flag = 0;
	if (board[a - 1][b] == player2) {
		dfs(a - 1, b, player2);
		if (flag == 0)
			ans++;
	}
	flag = 0;
	if (board[a + 1][b] == player2) {
		dfs(a + 1, b, player2);
		if (flag == 0)
			ans++;
	}
	flag = 0;
	if (board[a][b - 1] == player2) {
		dfs(a, b - 1, player2);
		if (flag == 0)
			ans++;
	}
	flag = 0;
	if (board[a][b + 1] == player2) {
		dfs(a, b + 1, player2);
		if (flag == 0)
			ans++;
	}
	flag = 0;
	if (ans > 0) {
		printf("K.O.\n");
		exit(0);
	}
}
void suicide(int a, int b) {
	flag = 0;
	dfs(a, b, player1);
	if (flag == 0) {
		printf("Suicide\n");
		exit(0);
	}
}
int main() {
	memset(board, 0, sizeof(board));
	for (int i = 1; i <= 9; i++) {
		for (int j = 1; j <= 9; j++) {
			scanf("%c", &board[i][j]);
		}
		getchar();
	}
	int a, b;
	memset(visit, 0, sizeof(visit));
	scanf("%d %d %c", &a, &b, &player1);
	a++, b++;
	board[a][b] = player1;
	if (player1 == 'O')
		player2 = 'X';
	else
		player2 = 'O';
	if_ko(a, b);
	suicide(a, b);
	printf("Safe\n");
	return 0;
}

#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<algorithm>
#include<iostream>
using namespace std;
long long int op[1000005];
int cmp(const void *a,const void *b) {
	return *(long long int*)b - *(long long int*)a;
}
int main() {
	memset(op, 0, sizeof(op));
	long long int n, m;
	long long  int v;
	scanf("%lld%lld%lld", &n, &m, &v);
	for (long long  int i = 0; i < n * m;i++) {
		scanf("%lld", &op[i]);
	}
	qsort(op, m * n, sizeof(long long int), cmp);
	long long int jizhun = op[0];
	for (long long int i = 1; i < n * m;i++) {
		if ((jizhun - op[i]) * i <= v) {
			v = v - (jizhun - op[i]) * i;
			jizhun = op[i];
		}
		else {
			long long int ok = v / i;
			jizhun = jizhun - ok;
			break;
		}
	}
	printf("%lld\n", jizhun);
	
	return 0;
}

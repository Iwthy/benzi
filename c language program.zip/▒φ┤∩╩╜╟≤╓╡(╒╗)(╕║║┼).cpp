#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<iostream>
#include<algorithm>
#include<stack>
#include<cmath> 
#define MAX 99999999
using namespace std;
int p = 0;
char s[100];
stack<int> shuzi;
stack<char> fuhao;
char operation[9] = { '+','-','*','/','%','^','(',')','#' };
char operationlevel[9][9] = {
	{'>','>','<','<','<','<','<','>','>'},
	{'>','>','<','<','<','<','<','>','>'},
	{'>','>','>','>','>','<','<','>','>'},
	{'>','>','>','>','>','<','<','>','>'},
	{'>','>','>','>','>','<','<','>','>'},
	{'>','>','>','>','>','<','<','>','>'},
	{'<','<','<','<','<','<','<','=','?'},// (#  
	{'>','>','>','>','>','>','?','>','>'},// )(
	{'<','<','<','<','<','<','<','?','='},// #)
};
 
int operate(int x,int y,char symbol) {
	switch (symbol) {
	case '+': return x + y;
	case '-': return x - y;
	case '*': return x * y;
	case '/': if (y) return x / y;
			else {
				printf("Divide 0.\n");
				return MAX;
			}
	case '%': return (int)fmod(x, y);
	case '^': if (y >= 0) return (int)pow(x, y);
			else {
				printf("error.\n");
				return MAX;
	}
	default: printf("error.\n");
		return MAX;
	}
}

char compare(char x,char y) {
	for (int i = 0; i <= 8;i++) {
		for (int j = 0; j <= 8;j++) {
			if (operation[i]==x&&operation[j]==y) {
				return operationlevel[i][j];
			}
		}
	}
}
int main() {
	int n, flag = 0;
	int temp = 0;
	scanf("%d",&n);
	while (n--) {
		memset(s, 0, sizeof(s));
		while (!shuzi.empty()) {
			shuzi.pop();
		}
		while (!fuhao.empty()) {
			fuhao.pop();
		}
		temp = 1;
		flag = 2;
		scanf("%s",s);
		strcat(s,"#");
		int len = strlen(s);
		p = 0;
		fuhao.push('#');
		for (int io = 0; io < len;io++) {
			if ((s[io] == '(' && s[io + 1] == '^') || (s[io] == '(' && s[io + 1] == '+') || (s[io] == '(' && s[io + 1] == '/') || (s[io] == '(' && s[io + 1] == '*') || (s[io] == '(' && s[io + 1] == '%')) {
				//�������ұ߽��ϴ������ʾ��
				printf("error.\n");
				goto j;
			}
		}
		k:while (s[p] != '#' || fuhao.top() != '#') {
			if (s[p] >= '0' && s[p] <= '9') {
				if (flag==0) {
					int kp = 0;
					kp = shuzi.top();
					shuzi.pop();
					shuzi.push(kp * 10 + (int)(s[p] - '0'));
					flag = 0;
					if (temp == -1 && (s[p + 1] == '+' || s[p + 1] == '-' || s[p + 1] == '*' || s[p + 1] == '/' || s[p + 1] == '%' || s[p + 1] == '^' || s[p + 1] == '#' || s[p + 1] == ')')) {
						//��*-�ȷ��ų��ֵ�ǰ���£�������ֺ�������˷���
						//֤����һ���������������
						//��һ������������ɵ������������ּ��ϸ���
						int what = shuzi.top();
						shuzi.pop();
						shuzi.push(-what);
						temp = 1;
					}
					p++;
					continue;
				}
				else if (flag==2) {
					shuzi.push((int)(s[p] - '0'));
					flag = 0;
					if (temp == -1 && (s[p + 1] == '+' || s[p + 1] == '-' || s[p + 1] == '*' || s[p + 1] == '/' || s[p + 1] == '%' || s[p + 1] == '^' || s[p + 1] == '#' || s[p + 1] == ')')) {
						//�˴�ҲҪ�жϣ��Է��ַ���Ŀ�����
						int what = shuzi.top();
						shuzi.pop();
						shuzi.push(-what);
						temp = 1;
					}
					p++;
					continue;
				}
			}
			else {
				flag = 2;
				if ((s[p] == '+' && s[p + 1] == '-' && s[p + 2] >= '0' && s[p + 2] <= '9') || (s[p] == '-' && s[p + 1] == '-' && s[p + 2] >= '0' && s[p + 2] <= '9') || (s[p] == '(' && s[p + 1] == '-' && s[p + 2] >= '0' && s[p + 2] <= '9')) {
					s[p + 1] = '?';
					temp = -1;
				}
				else if ((s[p] == '*' && s[p + 1] == '-' && s[p + 2] >= '0' && s[p + 2] <= '9') || (s[p] == '/' && s[p + 1] == '-' && s[p + 2] >= '0' && s[p + 2] <= '9')) {
					s[p + 1] = '?';
					temp = -1;
				}
				//*-  +-  --  /-  (- ���ǿ������ �ر�Ҫע��(-�������
				else if (fuhao.top() == '#' && s[p] == '-' && shuzi.empty()) {
					p++;
					temp = -1;
					goto k;
				}

				if (fuhao.empty()) {
					printf("error.\n");
					goto j;
					//һ�����ִ��󣬾������˳�ȥ
					//�˳�k���ѭ�� ��Ҫ��continue��
					//�˳�ѭ�����ֱ�ӽ��뵽��һ���ַ���
				}
				else {
					if (s[p]=='?') {
						p++;
						continue;
					}
					else {
						char ch = fuhao.top();
						fuhao.pop();
						char ans;
						ans = compare(ch, s[p]);
						if (ans=='?') {
							printf("error.\n");
							goto j;
						}
						else if(ans=='<') {
							fuhao.push(ch);
							fuhao.push(s[p]);
							p++;
							goto k;
						}
						else if (ans=='=') {
							p++;
							goto k;
						}
						else {
							//��x,y,ch�������㣬�������ִ��       

							int integer_x, integer_y;
							integer_y = shuzi.top();
							shuzi.pop();
							integer_x = shuzi.top();
							shuzi.pop();
							int judge = operate(integer_x, integer_y, ch);
							if (judge!=MAX) {
								shuzi.push(judge);
								continue;
							}
							else if (judge==MAX) {
								goto j;
							}
						}
					}
				}
			}
		}
		if (shuzi.size() == 1 && fuhao.size() == 1) {
			printf("%d\n",shuzi.top());
		}
		else {
			printf("error.\n");
		}
	j: {
		//����ѭ���Ŀຣ
		//ֻ��Ϊ���ܾ�������´�ѭ������
		
		}
	}
	return 0;
}




#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int result=0;
int vis[20][20];
int n;
void search(int cur){
	if(cur==n){
		result++;	
	}
	else
		for(int i=0;i<n;i++){
			if(!vis[0][i]&&!vis[1][cur+i]&&!vis[2][cur-i+n]){
				vis[0][i]=vis[1][cur+i]=vis[2][cur-i+n]=1;
				search(cur+1);
				vis[0][i]=vis[1][cur+i]=vis[2][cur-i+n]=0;
			}	
		}
}
int main(){
	while(1){
		memset(vis,0,sizeof(vis));
		result=0;
		scanf("%d",&n);
		if(n!=0){
			search(0);
			printf("%d\n",result);
		}
		else break;
	}
	
}

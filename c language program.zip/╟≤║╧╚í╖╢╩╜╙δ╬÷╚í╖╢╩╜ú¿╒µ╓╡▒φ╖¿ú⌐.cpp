#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<iostream>
#include<algorithm>
#include<stack>
using namespace std;
string s;
string s1;
int temp[210];
int temp1[210];
int flag[210];
int len=0;
char operation[7] = { '(',')','-','+','|','&','!' };
char operationlevel[7][7] = {
	{'<','=','<','<','<','<','<'},
	{' ','>','>','>','>','>',' '},
	{'<','>','>','>','>','>','<'},
	{'<','>','>','>','>','>','<'},
	{'<','>','>','>','>','>','<'},
	{'<','>','>','>','>','>','<'},
	{'<','>','>','>','>','>',' '}
	//��ȡ�Ƿ���Ҳ���뵽�ܵ�������� Ϊ��Ӧ��!(p-q)����� ��ˣ�Ҳ����ջ
};
char bijiao(char a,char b) {
	for (int i = 0; i < 7;i++) {
		for (int j = 0; j < 7;j++) {
			if (operation[i] == a && operation[j] == b) {
				return operationlevel[i][j];
			}
		}
	}
	return 0;
}
int jisuan(int a,char op,int b) {//���㺯��
	if (op=='&') {
		if (a == 1 && b == 1) {
			return 1;
		}
		else
			return 0;
	}
	else if (op=='|') {
		if (a == 1 || b == 1) {
			return 1;
		}
		else
			return 0;
	}
	else if (op=='-') {
		if (a == 1 && b == 0) {
			return 0;
		}
		else
			return 1;
	}
	else if (op=='+') {
		if ((a == 0 && b == 0) || (a == 1 && b == 1)) {
			return 1;
		}
		else
			return 0;
	}
}
int zhan() {
	s1 = s;
	for (int j = 0; j <= 200;j++) {
		for (int i = 0; i < len;i++) {
			if (temp1[j]==0&&j==s1[i]) {
				s1[i] = '0';
			}
			else if (temp1[j]==1&&j==s1[i]) {
				s1[i] = '1';
			}
		}
	}
	//cout << s1 << endl;
	stack<char> fuhao;
	stack<int> shuzi;//ջ�����ĺ���
	for (int i = 0; i < s1.size();i++) {
		if (s1[i] == '0' || s1[i] == '1') {
			shuzi.push(s1[i]-'0');
		}
		else {
			if (fuhao.empty()) {
				fuhao.push(s1[i]);
				continue;
			}
			else {
				char ch = fuhao.top();
				fuhao.pop();
				char ans = bijiao(ch, s1[i]);
				if (ans=='=') {
					continue;
				}
				else if (ans=='<') {
					fuhao.push(ch);
					fuhao.push(s1[i]);
					continue;
				}
				else if (ans=='>') {
					if (ch!='!') {
						int a2 = shuzi.top();
						shuzi.pop();
						int a1 = shuzi.top();
						shuzi.pop();
						int result = jisuan(a1, ch, a2);
						shuzi.push(result);
						i--;
						continue;
					}
					else if(ch=='!') {
						int ko = shuzi.top();
						shuzi.pop();
						if (ko==1) {
							shuzi.push(0);
						}
						else if (ko==0) {
							shuzi.push(1);
						}
						i--;
						continue;
					}
				}
			}
		}
	}
	if (fuhao.size()==2&&fuhao.top()=='!') {//������ջ�л�������Ԫ�����������Ǹ�Ԫ���ǣ�ʱ
		fuhao.pop();
		int k1 = shuzi.top();
		shuzi.pop();
		if (k1==0) {
			shuzi.push(1);
		}
		else if (k1==1) {
			shuzi.push(0);
		}
		char ch1 = fuhao.top();
		fuhao.pop();
		int a2 = shuzi.top();
		shuzi.pop();
		int a1 = shuzi.top();
		shuzi.pop();
		int result = jisuan(a1, ch1, a2);
		shuzi.push(result);
	}
	else if (fuhao.size()==1) {//�������ջ��ֻ��һ��Ԫ�� ����ڰ�����ջ�ڵ�Ԫ��ȫ��������
		char ch1 = fuhao.top();
		fuhao.pop();
		int a2 = shuzi.top();
		shuzi.pop();
		int a1 = shuzi.top();
		shuzi.pop();
		int result = jisuan(a1, ch1, a2);
		shuzi.push(result);//���Ľ���Ǵ���������ջ��
	}
	if (shuzi.size()==1) {
		//cout << shuzi.top() << endl;
		return shuzi.top();
		
	}
}
int main() {
	memset(temp, -1, sizeof(temp));
	memset(flag, 0, sizeof(flag));
	memset(temp1, -1, sizeof(temp1));
	cin >> s;
	len = s.size();
	int all_number = 0;
	for (int i = 0; i < len; i++) {
		if ((s[i] >= 'a' && s[i] <= 'z') || (s[i] >= 'A' && s[i] <= 'Z')) {
			temp[s[i]] = 1;
		}
	}//ֱ�����ַ���ASCII����뵽�����в������temp
	for (int i = 0; i < 200;i++) {
		if (temp[i]==1) {
			all_number++;
		}
	}//ת��ֵ���Ĳ���
	all_number = pow(2, all_number);
	for (int i = 0; i < all_number;i++) {
		int flag1 = i;
		for (int j = 200; j >= 0;j--) {
			temp1[j] = temp[j];
		}
		for (int j = 200; j >= 0;j--) {
			if (temp1[j]==1) {
				temp1[j] = flag1 % 2;
				flag1 = flag1 / 2;
			}
		}
		int zhenzhi = 0;
		zhenzhi = zhan();
		if (zhenzhi==1) {
			flag[i] = 1;
		}
	}
	int zhen_number = 0;
	for (int i = 0; i < all_number;i++) {
		if (flag[i]==1) {
			zhen_number++;
		}
	}
	if (zhen_number==all_number) {//�ж��Ƿ�������ʽ
		int what = 1;
		for (int i = 0; i < all_number; i++) {
			if (what < zhen_number && flag[i] == 1) {
				what++;
				printf("m%d �� ", i);
			}
			else if (what >= zhen_number && flag[i] == 1) {
				what++;
				printf("m%d", i);
			}
		}
		printf(" ; ");
		printf("1\n");
	}
	else if (zhen_number==0) {//�ж��Ƿ���ì��ʽ
		printf("0");
		printf(" ; ");
		int what1 = 1;
		for (int i = 0; i < all_number; i++) {
			if (what1 < all_number - zhen_number && flag[i] == 0) {
				what1++;
				printf("M%d �� ", i);
			}
			else if (what1 >= all_number - zhen_number && flag[i] == 0) {
				what1++;
				printf("M%d\n", i);
			}
		}
	}
	else {//������ʽҲ��ì��ʽ
		int what = 1;
		for (int i = 0; i < all_number; i++) {
			if (what < zhen_number && flag[i] == 1) {
				what++;
				printf("m%d �� ", i);
			}
			else if (what >= zhen_number && flag[i] == 1) {
				what++;
				printf("m%d", i);
			}
		}
		printf(" ; ");
		int what1 = 1;
		for (int i = 0; i < all_number; i++) {
			if (what1 < all_number - zhen_number && flag[i] == 0) {
				what1++;
				printf("M%d �� ", i);
			}
			else if (what1 >= all_number - zhen_number && flag[i] == 0) {
				what1++;
				printf("M%d\n", i);
			}
		}
	}
	return 0;
}

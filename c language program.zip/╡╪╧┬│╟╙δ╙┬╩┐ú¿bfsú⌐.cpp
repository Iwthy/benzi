#include<cstdio>   
#include<iostream>    
#include<vector>     
#include<queue>    
#include<algorithm>    
#include<cstring>    
using namespace std;    
    
const int maxn=100+10;    
const int dx[]={0,0,1,-1};    
const int dy[]={1,-1,0,0};    
    
struct node{    
    int x,y,z;    
    int step;    
        
    node(int _x,int _y,int _z,int _step):x(_x),y(_y),z(_z),step(_step){}    
};    
    
queue<node> duilie;    
int vis[maxn][maxn][60];  
char mp[maxn][maxn];    
int main(){    
   int T;  
   int n,m,k;  
   int start_x,start_y,end_x,end_y;  
   int i,j;  
   int op;  
    scanf("%d",&T);  
    while(T--){  
        memset(mp,0,sizeof(mp));  
    n=0;  
    m=0;  
    k=0;  
    op=0;  
    start_x=0;start_y=0;  
    end_x=0;end_y=0;  
    i=0;j=0;  
    int flag=0;  
    scanf("%d %d",&n,&m);    
       
    scanf("%d",&op);    
      
    for(i=0;i<n;++i){    
        scanf("%s",&mp[i]);    
    }    
    for(i=0;i<n;++i){    
        for(j=0;j<m;++j){    
            if(mp[i][j]=='S'){    
                start_x=i;    
                start_y=j;    
            }    
            if(mp[i][j]=='E'){  
                end_x=i;  
                end_y=j;  
            }   
        }    
    }    
    memset(vis,0,sizeof(vis));    
    duilie.push(node(start_x,start_y,0,0));    
    vis[start_x][start_y][0]=1;    
    int ans=0;    
    while(!duilie.empty()){    
        node tmp=duilie.front();    
        duilie.pop();    
          
        if(mp[tmp.x][tmp.y] =='E'){  
            ans = tmp.step;  
            flag = 1;     
           goto p;  
  
          }  
        for(i=0;i<4;++i){  //һ��һ��ɨ   
            int x=tmp.x+dx[i];    
            int y=tmp.y+dy[i];    
              
           if((tmp.z+1)%op==0){  
                if(x<0||x>=n||y<0||y>=m||mp[x][y]=='#'||vis[x][y][(tmp.z+1)%op]==1){  
                    continue;  
                 }  
             }  
            else {  
                if(x<0||x>=n||y<0||y>=m||mp[x][y]=='#'||mp[x][y]=='*'||vis[x][y][(tmp.z+1)%op]==1){  
                    continue;  
                 }  
             }  
               
             duilie.push(node(x,y,tmp.z+1,tmp.step+1));  
             vis[x][y][(tmp.z+1)%op]=1;  
        }    
    }    
          
        p:{  
            if(flag==1){    
            printf("%d\n",ans);    
        }    
        else{    
            printf("-1\n");    
        }    
       
          }  
        while(!duilie.empty()){  
            duilie.pop();  
        }  
   }  
       
     return 0;  
}  

#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int n;
int a[100010];
long long int all, k;
int check(long long int x) {
	long long int temp1 = 0, temp2 = 0;
	long long int now = a[1];
	int left = 0, right = 1;
	while (left <= right && right <= n) {
		if (now >= x) {
			if (now == x) {
				temp2++;
			}
			else
				temp1++;
			temp1 += n - right;
			left++;
			now -= a[left];
		}
		else if (now<x) {
			right++;
			now += a[right];
		}
		//printf("l= %d,r= %d, tmp1= %lld, tmp2= %lld\n",l,r,tmp1,tmp2); 
	}
	if (all - temp1 - temp2 < k && all - temp1 >= k) {
		return 1;
	}
	else if (all - temp1 - temp2 >= k) {
		return 0;
	}
	else
		return 9;
}
int main() {
	scanf("%d%lld", &n, &k);
	for (int i = 1; i <= n;i++) {
		scanf("%d", &a[i]);
	}
	long long int sum=0;
	for (int i = 1; i <= n;i++) {
		sum += a[i];
	}
	all = 1LL * n * (n + 1) / 2;
	long long int left = 1, right = sum;
	while (left<=right) {
		long long int mid = (left + right) / 2;
		int flag = check(mid);
		if (flag == 1) {
			return printf("%lld\n", mid), 0;
		}
		else if (flag == 0) {
			right = mid - 1;
		}
		else
			left = mid + 1;
	}
	return 0;
}
